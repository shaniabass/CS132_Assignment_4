var i = 0;
var j = 0;
var k = 0;
var l = 0;
function increase1()
{
i++
document.getElementById("counter1").value=i;
}

function increase2()
{
j++
document.getElementById("counter2").value=j;
}

function increase3()
{
k++
document.getElementById("counter3").value=k;
}

function increase4()
{
l++
document.getElementById("counter4").value=l;
}

