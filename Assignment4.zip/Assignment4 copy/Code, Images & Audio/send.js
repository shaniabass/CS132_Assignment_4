


function change()
{
document.getElementById("myButton1").value="Sent";
document.getElementById("myButton1").style.color="#71C4E5";
document.getElementById("input1").value = "";
document.getElementById("input2").value = "";
document.getElementById("checkbox1").checked = false;
document.getElementById("checkbox2").checked = false;
document.getElementById("checkbox3").checked = false;
document.getElementById("checkbox4").checked = false;
document.getElementById("checkbox5").checked = false;
document.getElementById("checkbox6").checked = false;
document.getElementById("input3").value = "";
}
