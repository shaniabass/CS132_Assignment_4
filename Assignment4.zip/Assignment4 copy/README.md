#Notes About Testing
- Please open the web app via login.html
- The login page will display an error message if "error" (all lowercase) is entered as the password, and will let you through otherwise
- I have opimized the mobile view to suit the portrait iPhone 5/SE dimensions, so please test it in this setting

#Known Bugs
- For some reason the input fields on the login page of the mobile view have stopped allowing text to be entered (though they previously worked) - they work perfectly in the desktop view so if you wish to see the formatting of the error message you may have to enter "error" in the desktop view and then switch it to mobile while the error message is still up - this was working before and randomly stopped, so this issue may resolve itself

#Notes About Changes From Mockup

- ##General
    - I have slightly alterered the size of certain elements/spacing between them for readablity purposes as I created my mockup using slightly different dimensions (my mobile mockup was an iPhone 7, for example), but everything is in the same position, unless otherwise noted
    - All bullet points are now circles instead of dashes, again for readability
    - I have used the exact same backgound gradient as in my mockup, but the colors appear less saturated in the browser - I decided not to fix this as I felt that the original colors were slightly overpowering anyway
    
- ##Home 
    - I have made the navigation buttons slightly wider for readbility purposes
    - In the mobile version, I made all the text bold as I felt it was being swallowed up by the background
    - I also made the mobile version scrollable, as I felt the page was too cluttered
    
- ##Track
    - The buttons now begin blank instead of at 0 - I did this to reduce the initial amount of visual information on the page, and also to make it less confusing - it is now clearer as to which causes never occur
    
- ##Send To Doctor
    - I changed the form on this page quite a bit, as I felt that my mockup had readability issues: I  made all the sections the same length and shorter, and I stacked the checkboxes on top of each other instead of in rows of 2, and centered the whole form. I felt that these changes made everything more coherent and easier to follow.
    - I also put the navigation buttons more directly under the form in the mobile version, as they looked odd when further out

- ##Relax
    - For the "Play Audio" feature, I decided to use HTML controls instead of a button as the symbols (play, pause etc.) are more recognizable and the controls allow for more features than just playing and pausing (namely re-winding, fast-forwarding and changing the volume)
